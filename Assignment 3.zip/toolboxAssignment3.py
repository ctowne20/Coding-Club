# Carrieann Towne
# February 20, 2020
# Assignment 3 Toolbox File

import importlib

def newFunc(fileName):
	fileArr = []
	
	importFile = open(fileName,"r")
	
	for x in importFile:
		fileArr.append(x)
	
	return fileArr

